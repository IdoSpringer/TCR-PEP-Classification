import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
import torch.optim as optim
import pickle
from models import *
# import glob
# import os
import random
# import pandas as pd
import numpy as np
import time
# import itertools
# from collections import Counter
from sklearn import metrics
# import seaborn as sns
# import matplotlib.pyplot as plt
import sys
import json
from sklearn.model_selection import train_test_split


def prepare_sequence(seq, to_ix, lst_triplets):
    idxs = []
    lst_triplets_ind = []
    for i in range(3, len(seq) - 3):
        trp = seq[i:i + 3]
        if trp in lst_triplets:
            q = [to_ix[v] for v in seq[i:i + 3]]
            idxs.append(q)

            tensor = torch.LongTensor(q)
            lst_triplets_ind.append(autograd.Variable(tensor))

    return lst_triplets_ind


def prepare_pep(pep, to_ix):
    q = [to_ix[l] for l in pep]
    tensor = torch.LongTensor(q)
    tensor_grad = autograd.Variable(tensor)

    return tensor_grad


def YnumpyToTensor(y_data_np):
    y_data_np = y_data_np.reshape((y_data_np.shape[0], 1))  # Must be reshaped for PyTorch!
    print(y_data_np.shape)
    print(type(y_data_np))
    Y_tensor = autograd.Variable(torch.from_numpy(y_data_np)).type(torch.FloatTensor)


def evaluation_model(x_data, y_data, aux_data, model_, type_eval, num_of_lbl, device, p_vec):
    model_.eval()
    y_hat = []
    y_true = []
    # y_pred_auc=[]
    word_to_ix, peptides_list, pep_to_ix = aux_data
    data_test = list(zip(x_data, y_data))
    data_divided_test = chunks(data_test, 10)
    specific_batch_test = list(data_divided_test)
    for batch_test in specific_batch_test:
        x, y = zip(*batch_test)
        input_seq, sequences_len = get_batch(x, word_to_ix)
        if device.type != 'cpu':
            input_seq = input_seq.to(device)
            sequences_len = sequences_len.to(device)

        current_pep_ = np.random.choice(num_of_lbl, 1, replace=False, p=p_vec)[0]
        lst_of_pep_ix = [current_pep_] * len(y)
        lst_of_pep = [peptides_list[i] for i in lst_of_pep_ix]
        input_pep, peptides_len = get_batch(lst_of_pep, pep_to_ix)
        if device.type != 'cpu':
            input_pep = input_pep.to(device)
            peptides_len = peptides_len.to(device)

        model_.zero_grad()
        # opt.zero_grad()

        y_predict_ = model_.forward(input_seq, sequences_len, input_pep, peptides_len)
        y_true.extend((np.asarray(lst_of_pep_ix) == np.asarray(y).astype(int)).astype(int))

        # y_pred_auc.append(y_predict_.data[0])
        y_hat.extend(y_predict_.view(-1).cpu().data.numpy().round())

    precision, recall, fbeta_score, _ = metrics.precision_recall_fscore_support(y_true, y_hat, average='binary')

    return precision, recall, fbeta_score


def valid_seq(seq, aa):
    stats = True
    for l in seq:
        if l not in aa:
            stats = False
    if len(seq) < 7:
        stats = False
    return stats


def get_rand_lbl(y_true, num_of_lbl):
    p = [0.5/(num_of_lbl-1)]*num_of_lbl
    p[int(y_true)] = 0.5
    lbl = np.random.choice(np.arange(0, num_of_lbl), p=p)

    return lbl


def data_generator(data_train, data_test, peptides):
    seq_lists = [data_train[pep_name] for pep_name in peptides]
    x_tr = [x for l in seq_lists for x in l]
    y_tr = [[i] * len(x) for i, x in enumerate(seq_lists)]
    y_tr = [item for sublist in y_tr for item in sublist]

    seq_lists = [data_test[pep_name] for pep_name in peptides]
    x_te = [x for l in seq_lists for x in l]
    y_te = [[i] * len(x) for i, x in enumerate(seq_lists)]
    y_te = [item for sublist in y_te for item in sublist]

    return x_tr, y_tr, x_te, y_te


def chunks(l, n):
    """Yield successive n-sized chunks from l."""
    seq_length = np.asarray([len(x[0]) for x in l])

    tmp_l = [[] for i in range(len(set(seq_length)))]
    for i, j in zip(set(seq_length), tmp_l):
        j.extend(np.asarray(l)[seq_length == i])
    for g in tmp_l:
        for i in range(0, len(g), n):
            yield g[i:i + n]
    # l_t = [x for x in l if len(x[0]) == 13]
    # l = l_t
    # l.sort( key=lambda x: len(x[0]))
    # for i in range(0, len(l), n):
    #     yield l[i:i + n]


def get_batch(dat,  to_ix):
    vectorized_seqs = [[to_ix[l] for l in pep] for pep in dat]
    # get sequences lengths
    seq_lengths = torch.LongTensor([len(x) for x in vectorized_seqs])

    # dump padding everywhere, and place seqs on the left.
    # NOTE: you only need a tensor as big as your longest sequence
    seq_tensor = autograd.Variable(torch.zeros((len(vectorized_seqs), seq_lengths.max()))).long()
    for idx, (seq, seqlen) in enumerate(zip(vectorized_seqs, seq_lengths)):
        seq_tensor[idx, :seqlen] = torch.LongTensor(seq)

    # SORTING sequences by length
    seq_lengths, length_id = seq_lengths.sort(0, descending=True)
    # ordering batch
    seq_tensor = seq_tensor[length_id]

    seq_tensor = seq_tensor.transpose(0, 1)  # (B,L,D) -> (L,B,D)

    return seq_tensor, seq_lengths


def load_data():
    with open('train sequences.pickle', 'rb') as handle:
        train_lst_ = pickle.load(handle)
    with open('test sequences.pickle', 'rb') as handle:
        test_lst_ = pickle.load(handle)
    with open('triplets before.pickle', 'rb') as handle:
        dict_before_ = pickle.load(handle)
    with open('triplets after.pickle', 'rb') as handle:
        dict_after_ = pickle.load(handle)

    return train_lst_, test_lst_, dict_before_, dict_after_


def get_letters_seq(data_):
    a1 = [set(x) for l in data_.values() for x in l]
    letter_ = ['<PAD>'] + list(set([x for l in a1 for x in l]))

    word_to_ix_ = dict((i, j) for j, i in enumerate(letter_))
    ix_to_word_ = dict((j, i) for j, i in enumerate(letter_))

    return letter_, word_to_ix_, ix_to_word_


def get_letters_pep(peptides_lst):
    word_to_ix_ = dict((i, j) for j, i in enumerate(['<PAD>']+list(set(x for l in peptides_lst for x in l))))
    ix_to_word_ = dict((j, i) for j, i in enumerate(['<PAD>']+list(set(x for l in peptides_lst for x in l))))

    return word_to_ix_, ix_to_word_


def train(model, current_data, aux_data, optimizer, loss_function, epoch_pep, device):
    model.train()
    word_to_ix,  peptides_list, pep_to_ix = aux_data
    total_loss = torch.Tensor([0])
    if device.type != 'cpu':
        total_loss = total_loss.to(device)
    for batch_ in current_data:
        optimizer.zero_grad()

        x_train, y_train = zip(*batch_)
        input_seq, sequences_len = get_batch(x_train, word_to_ix)
        if device.type != 'cpu':
            input_seq = input_seq.to(device)
            sequences_len = sequences_len.to(device)
        lst_of_pep_ix = [epoch_pep] * len(y_train)
        lst_of_pep = [peptides_list[i] for i in lst_of_pep_ix]
        input_pep, peptides_len = get_batch(lst_of_pep, pep_to_ix)
        if device.type != 'cpu':
            input_pep = input_pep.to(device)
            peptides_len = peptides_len.to(device)

        y_predict = model.forward(input_seq, sequences_len, input_pep, peptides_len)
        new_y = (np.asarray(lst_of_pep_ix) == np.asarray(y_train).astype(int)).astype(int)
        target = autograd.Variable(torch.FloatTensor([new_y])).view(-1)
        if device.type != 'cpu':
            target = target.to(device)

        loss = loss_function(y_predict.view(-1), target)

        loss.backward()
        optimizer.step()

        total_loss += loss.item()
    return total_loss


def epoch_measures(x_dat, y_dat, aux_data, model, type_e, num_of_peptides, device, P):
    lst_result_ = []
    precision_lst, recall_lst, fbeta_lst = zip(*[evaluation_model(x_dat, y_dat, aux_data, model, type_e, num_of_peptides, device, P)
                                                 for i in range(20)])
    max_ind, min_ind = np.argmax(fbeta_lst), np.argmin(fbeta_lst)
    lst_result_.append((fbeta_lst[max_ind], precision_lst[max_ind], recall_lst[max_ind]))

    return lst_result_


def best_results(lst_):
    max_ind = np.argmax(np.asarray(lst_).reshape((len(lst_), 3))[:, 0])
    f1, precision, recall = np.round(lst_[max_ind][0], 5)

    return precision, recall, f1, max_ind


def print_line(precision_, recall_, f1_):
    return ','+str(precision_)+','+str(recall_)+','+str(f1_)+','


def do_one_train(model_name, peptides_lst, dat, device, params=None):
    train_lst, test_lst, word_to_ix, ix_to_word, letters = dat
    num_of_peptides = len(peptides_lst)
    x_train, y_train, x_test, y_test = data_generator(train_lst, test_lst, peptides_lst)
    data = list(zip(x_train, y_train))
    if params['divide']:
        x_dev, x_test, y_dev, y_test = train_test_split(x_test, y_test, test_size=0.3, random_state=42)
    else:
        x_dev, y_dev = x_test, y_test

    pep_to_ix, ix_to_pep = get_letters_pep(peptides_lst)
    aux_data = [word_to_ix, peptides_lst, pep_to_ix]

    # building model
    if model_name == 'one':
        model = LSTMClassifierSimple(20, 40, len(word_to_ix), 1, len(pep_to_ix), device)
    elif model_name == 'double':
        model = DoubleLSTMClassifier(20, 40, len(word_to_ix), 1, len(pep_to_ix), device)
    elif model_name == 'upgrade':
        n_layers = params['n_layers']
        bi_lstm = params['bi_lstm']
        model = DoubleLSTMClassifierUpgrade(20, 40, len(word_to_ix), 1, len(pep_to_ix), device, n_layers, bi_lstm)

    if device.type != 'cpu':
        model = model.to(device)
    loss_function = nn.BCELoss()
    opt = optim.Adam(model.parameters(), weight_decay=1e-3)

    lst_result_train = []
    lst_result_dev = []
    lst_result_test = []

    p_vec = np.array([len(train_lst[x]) for x in peptides_lst]) / sum([len(train_lst[x]) for x in peptides_lst])
    ts_ = time.time()
    for epoch in range(270 * int(num_of_peptides * 1.6)):
        # shuffling and divide data
        random.shuffle(data)
        data_divided = chunks(data, 10)
        specific_batch = list(data_divided)
        # choose peptide
        current_pep = np.random.choice(num_of_peptides, 1, replace=False, p=p_vec)[0]
        lss_ = train(model, specific_batch, aux_data, opt, loss_function, current_pep, device)

        if epoch % 10 == 0:
            print('num of labels: ', num_of_peptides, round(lss_.item() / len(specific_batch), 4))
            if epoch > 60:
                lst_result_train.append(epoch_measures(x_train, y_train, aux_data, model, True, num_of_peptides, device, p_vec))
                lst_result_dev.append(epoch_measures(x_dev, y_dev, aux_data, model, True, num_of_peptides, device, p_vec))
                if params['divide']:
                    lst_result_test.append(epoch_measures(x_test, y_test, aux_data, model, True, num_of_peptides, device, p_vec))

    print(time.time() - ts_)

    precision_t, recall_t, f1_t, _ = best_results(lst_result_train)
    train_line = print_line(precision_t, recall_t, f1_t)
    precision_, recall_, f1_, max_ind = best_results(lst_result_dev)
    dev_line = print_line(precision_, recall_, f1_)
    if params['divide']:
        precision_, recall_, f1_, max_ind = best_results(lst_result_test)
        test_line_best = print_line(precision_, recall_, f1_)
        f1, precision, recall = np.round(lst_result_dev[max_ind][0], 5)
        test_line = print_line(precision, recall, f1)

        return model, train_line, dev_line, test_line_best, test_line
    else:
        return model, train_line, dev_line


def main(argv):
    """
    num_lstm: number of lstm (max 2),
    bi_lstm: True for bi-lstm,
    "num_layers": number of lstm layers,
    "dropout": prob for  dropout (at least two layers,
    "save_to_file": True for  save results,
    "file_name": name file *.csv,
    "num_of_peptides": number of peptides to run,
    "cuda": gpu device
    """

    with open(argv[-1], 'r') as param_file:
        arguments = json.load(param_file)

    cuda_device_num = "cuda:" + str(arguments['cuda'])

    device = torch.device(cuda_device_num if torch.cuda.is_available() else "cpu")
    # Assume that we are on a CUDA machine, then this should print a CUDA device:
    print(device)
    gpu = torch.cuda.is_available()

    train_lst, test_lst, dict_before, dict_after = load_data()

    letters, word_to_ix, ix_to_word = get_letters_seq(train_lst)
    # [len(x) for x in train_lst.values()]
    data = train_lst, test_lst, word_to_ix, ix_to_word, letters
    sorted_x = sorted(train_lst, key=lambda k: len(train_lst[k]), reverse=True)
    [len(train_lst[x]) for x in sorted_x]

    # peptides_list = list(train_lst.keys())[:num_of_peptides]
    # peptides_list = ['GLCTLVAML', 'LPRRSGAAGA']
    # num_of_peptides = len(peptides_list)

    # classifier model to use
    params ={}
    params['divide'] = arguments == 'yes'
    if bool(arguments['bi_lstm']):
        bi_l = arguments['bi_lstm']
        params['n_layers'] = int(arguments['num_layers'])
        params['bi_lstm'] = bool(arguments['bi_lstm'])
        mode_name = 'upgrade'
    elif arguments['num_lstm'] == 2:
        mode_name = 'double'
    else:
        mode_name = 'one'

    # number of classes
    num_of_peptides = arguments['num_of_peptides']
    if num_of_peptides.isdigit():
        num_of_peptides = int(num_of_peptides)
        num_of_training = range(num_of_peptides, num_of_peptides+1)
    elif num_of_peptides == 'all':
        num_of_training = range(2, 16)

    else:
        v1, v2 = int(num_of_peptides.split('-')[0]), int(num_of_peptides.split('-')[-1])
        num_of_training = range(v1, v2+1)


    for num_of_peptides in num_of_training:
        peptides_list = sorted_x[:num_of_peptides]
        best_f1_test = 0.
        best_model = None

        for trial in range(6):
            if params['divide']:
                fit_model, train_line, dev_line, test_line_best, test_line = do_one_train(mode_name, peptides_list,
                                                                                          data, device, params)
            else:
                fit_model, train_line, dev_line = do_one_train(mode_name, peptides_list, data, device, params)
                test_line = dev_line
            curr_result = float(test_line.split(',')[-2])

            print(curr_result)
            if curr_result > best_f1_test:
                best_f1_test = curr_result
                if params['divide']:
                    best_model = fit_model, train_line, dev_line, test_line_best, test_line
                else:
                    best_model = fit_model, train_line, dev_line

        if params['divide']:
            fit_model, train_line, dev_line, test_line_best, test_line = best_model
        else:
            fit_model, train_line, dev_line = best_model
        print(test_line)
        if bool(arguments['save_to_file']):
            f_name = arguments['file_name']
            with open(f_name, "a") as my_file:
                my_file.write(fit_model.name_model() + ' ' + str(num_of_peptides) + train_line + 'train' + '\n')
                my_file.write(fit_model.name_model() + ' ' + str(num_of_peptides) + dev_line + 'dev' + '\n')
                if params['divide']:
                    my_file.write(fit_model.name_model() + ' ' + str(num_of_peptides) + test_line + 'test' + '\n')
                    my_file.write(fit_model.name_model() + ' ' + str(num_of_peptides) + test_line_best + 'test best' + '\n')

        # saving model
        if bool(arguments['saving model']):
            torch.save(fit_model, arguments['model file name']+'.pt')
            torch.save(fit_model.state_dict(), arguments['model file name']+'_param.pt')

if __name__ == '__main__':
    main(sys.argv)

# model_name num_classes (num_layers bi-lstm) file_name
